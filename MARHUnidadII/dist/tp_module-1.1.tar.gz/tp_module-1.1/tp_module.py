def trabajo(f:float, d:float)-> float:
    t = f * d
    return t


def potencia(w:float, t:float)-> float:
    p =  w / t
    return p