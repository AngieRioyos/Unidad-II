from setuptools import setup

setup(
    name='tp_module',
    version='1.1',
    description='funciones_de_trabajo_potencia',
    author='Angie Rioyos',
    author_email='angiee.171996@gmail.com',
    url='trello.com/pa',
    py_modules=['tp_module'],
)
